# Intelligent Indoor Inspection Robot
### ROS 2 Humble | BehaviorTree.CPP | RTAB-Map | Nav2 | Gazebo Classic

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                       ROS 2 Humble                              │
│                                                                 │
│  ┌──────────┐   /scan    ┌────────────┐  /map   ┌──────────┐  │
│  │ Gazebo   │──────────▶│  RTAB-Map  │────────▶│  Nav2    │  │
│  │ Classic  │  /odom    │  (3D SLAM) │         │ (Nav.)   │  │
│  │ World    │──────────▶│            │         │          │  │
│  │          │  /camera  │            │         │          │  │
│  │ Diff     │──────────▶│            │         │          │  │
│  │ Drive    │           └────────────┘         └──────────┘  │
│  │ Robot    │                                       ▲         │
│  └──────────┘                                       │         │
│       ▲                                   /navigate_to_pose   │
│       │ /cmd_vel                               │               │
│  ┌────┴───────────────────────────────────────┴──────────┐   │
│  │              Behavior Tree Executor                    │   │
│  │                                                        │   │
│  │  ReactiveSequence                                      │   │
│  │  ├─ CheckEmergency ──────────── /emergency_stop        │   │
│  │  ├─ BuildMapAction ──────────── (RTAB-Map active)      │   │
│  │  ├─ Fallback: obstacle                                 │   │
│  │  │   ├─ Inverter(CheckObstacle) ── /scan               │   │
│  │  │   └─ AvoidObstacleAction ────── /cmd_vel            │   │
│  │  ├─ Fallback: battery                                  │   │
│  │  │   ├─ Inverter(CheckBatteryLow) ─ /battery_level     │   │
│  │  │   └─ DockAction + RechargeAction                    │   │
│  │  ├─ Fallback: mapping                                  │   │
│  │  │   ├─ Inverter(CheckMappingComplete) ─ /rtabmap/...  │   │
│  │  │   └─ SaveMapAction                                  │   │
│  │  └─ ExploreAction ──────────── /navigate_to_pose       │   │
│  │                                                        │   │
│  │  + BatterySimulator + LoopClosureSimulator + VoiceNode │   │
│  └────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Packages

| Package | Description |
|---------|-------------|
| `inspection_robot_description` | URDF/Xacro robot model (diff-drive, LiDAR, RGBD camera) |
| `inspection_robot_gazebo` | Gazebo world (indoor 16×16m, rooms, obstacles, charging station) |
| `inspection_robot_bt` | All BT nodes + executor + battery/voice simulators |
| `inspection_robot_bringup` | Master launch, Nav2 config, RTAB-Map launch |

---

## Behavior Tree

```
BT Start
│
└─ ReactiveSequence (root — re-checks every tick)
   │
   ├─ [GUARD] CheckEmergency → halt everything if /emergency_stop=true
   │
   ├─ BuildMapAction       → announces RTAB-Map is active
   │
   ├─ Fallback (obstacle)
   │   ├─ Inverter(CheckObstacle)   No obstacle? → pass
   │   └─ Sequence
   │       ├─ VoiceNotify "Obstacle detected"
   │       └─ AvoidObstacleAction   Stop → Back 1.5s → Turn 2s
   │
   ├─ Fallback (battery)
   │   ├─ Inverter(CheckBatteryLow) Battery OK? → pass
   │   └─ Sequence
   │       ├─ VoiceNotify "Battery low"
   │       ├─ DockAction            Nav2 goal to dock pose (-6, -6)
   │       ├─ RechargeAction        Simulate recharge to 90%
   │       └─ VoiceNotify "Recharged"
   │
   ├─ Fallback (mapping complete)
   │   ├─ Inverter(CheckMappingComplete) Not done? → pass
   │   └─ Sequence
   │       ├─ VoiceNotify "Mapping complete"
   │       ├─ SaveMapAction         Saves DB + 2D occupancy map
   │       └─ VoiceNotify "Map saved"
   │
   └─ ExploreAction        → random Nav2 goal within 6m radius
```

---

## Quick Start

### Prerequisites
- Ubuntu 22.04
- ROS 2 Humble
- VirtualBox / bare metal (LIBGL_ALWAYS_SOFTWARE=1 set in run.sh)

### 1. Build
```bash
cd ~/inspection_robot_ws
bash build.sh
```

### 2. Run (full system)
```bash
bash run.sh
```
Opens a tmux session with windows:
- `gazebo`       — full simulation
- `bt_monitor`   — voice text echo
- `battery`      — battery level watch
- `rtab_monitor` — loop closure counter
- `emergency`    — manual stop console
- `teleop`       — keyboard override

### 3. Emergency Stop
```bash
ros2 topic pub --once /emergency_stop std_msgs/msg/Bool "{data: true}"
```

### 4. Manual teleop override
Switch to `teleop` window in tmux — uses `teleop_twist_keyboard`.

---

## Key Topics

| Topic | Type | Description |
|-------|------|-------------|
| `/scan` | `sensor_msgs/LaserScan` | 360° LiDAR |
| `/cmd_vel` | `geometry_msgs/Twist` | Robot velocity |
| `/odom` | `nav_msgs/Odometry` | Wheel odometry |
| `/battery_level` | `std_msgs/Float32` | 0–100 % |
| `/emergency_stop` | `std_msgs/Bool` | Halt robot |
| `/voice_text` | `std_msgs/String` | TTS announcements |
| `/rtabmap/loop_closures` | `std_msgs/Int32` | SLAM progress |
| `/rtabmap/mapData` | `rtabmap_msgs/MapData` | 3D map |
| `/map` | `nav_msgs/OccupancyGrid` | 2D Nav2 map |
| `/navigate_to_pose` | Nav2 Action | Exploration goals |

---

## Customisation

### Change obstacle threshold
Edit `bt_trees/inspection_bt.xml`:
```xml
<CheckObstacle min_range_threshold="0.5"/>   <!-- metres -->
```

### Change battery alarm level
```xml
<CheckBatteryLow low_threshold="20.0"/>      <!-- % -->
```

### Change mapping completion criterion
```xml
<CheckMappingComplete required_closures="10"/>
```

### Change exploration radius
```xml
<ExploreAction explore_radius="6.0" nav_timeout="30.0"/>
```

### Change charging station location
Match the world SDF `charging_station` pose:
```xml
<DockAction dock_pose_x="-6.0" dock_pose_y="-6.0"/>
```
