#!/usr/bin/env python3
"""Launch Gazebo simulation with the indoor inspection world and robot."""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, ExecuteProcess,
                             IncludeLaunchDescription, TimerAction)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_desc    = get_package_share_directory('inspection_robot_description')
    pkg_gazebo  = get_package_share_directory('inspection_robot_gazebo')
    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')

    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    world_file   = os.path.join(pkg_gazebo, 'worlds', 'indoor_inspection.world')
    urdf_file    = os.path.join(pkg_desc, 'urdf', 'inspection_robot.urdf.xacro')
    robot_desc   = Command(['xacro ', urdf_file])

    # ── Gazebo server + client ──────────────────────────────────────────────
    gzserver = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzserver.launch.py')),
        launch_arguments={'world': world_file,
                          'pause': 'false'}.items())

    gzclient = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzclient.launch.py')))

    # ── Robot state publisher ───────────────────────────────────────────────
    rsp = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[{'use_sim_time': use_sim_time,
                     'robot_description': robot_desc}],
        output='screen')

    # ── Spawn robot ─────────────────────────────────────────────────────────
    spawn = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description',
                   '-entity', 'inspection_robot',
                   '-x', '0.0', '-y', '0.0', '-z', '0.1'],
        output='screen')

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='true'),
        gzserver,
        gzclient,
        rsp,
        TimerAction(period=3.0, actions=[spawn]),
    ])
