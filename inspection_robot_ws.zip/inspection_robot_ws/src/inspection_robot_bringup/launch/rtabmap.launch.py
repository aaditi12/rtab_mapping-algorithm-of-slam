#!/usr/bin/env python3
"""Launch RTAB-Map for RGB-D + LiDAR 3D mapping."""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='true'),

        Node(
            package='rtabmap_slam',
            executable='rtabmap',
            name='rtabmap',
            output='screen',
            parameters=[{
                'use_sim_time':            use_sim_time,
                'subscribe_depth':         True,
                'subscribe_scan':          True,
                'subscribe_odom_info':     False,
                'frame_id':                'base_footprint',
                'odom_frame_id':           'odom',
                'map_frame_id':            'map',
                'database_path':           '/tmp/rtabmap.db',
                'Rtabmap/DetectionRate':   '1.0',
                'Reg/Strategy':            '1',     # ICP
                'Reg/Force3DoF':           'false',
                'RGBD/ProximityBySpace':   'true',
                'RGBD/AngularUpdate':      '0.05',
                'RGBD/LinearUpdate':       '0.05',
                'RGBD/OptimizeFromGraphEnd':'false',
                'Grid/FromDepth':          'false',  # Use laser for 2D grid
                'Mem/IncrementalMemory':   'true',
                'Mem/InitWMWithAllNodes':  'true',
                'approx_sync':             True,
            }],
            remappings=[
                ('rgb/image',       '/camera/image_raw'),
                ('rgb/camera_info', '/camera/camera_info'),
                ('depth/image',     '/camera/depth/image_raw'),
                ('scan',            '/scan'),
                ('odom',            '/odom'),
            ],
        ),

        # Visualise the RTAB-Map output in RViz
        Node(
            package='rtabmap_viz',
            executable='rtabmap_viz',
            name='rtabmap_viz',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time,
                          'subscribe_depth': True,
                          'subscribe_scan':  True,
                          'frame_id':        'base_footprint'}],
            remappings=[
                ('rgb/image',       '/camera/image_raw'),
                ('rgb/camera_info', '/camera/camera_info'),
                ('depth/image',     '/camera/depth/image_raw'),
                ('scan',            '/scan'),
                ('odom',            '/odom'),
            ],
        ),
    ])
