#!/usr/bin/env python3
"""
inspection_robot_bringup — master launch
Starts: Gazebo → RSP → Nav2 → RTAB-Map → BT Executor
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, IncludeLaunchDescription,
                             TimerAction)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_gazebo  = get_package_share_directory('inspection_robot_gazebo')
    pkg_bringup = get_package_share_directory('inspection_robot_bringup')
    pkg_bt      = get_package_share_directory('inspection_robot_bt')

    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    bt_file = os.path.join(pkg_bt, 'bt_trees', 'inspection_bt.xml')

    # ── 1. Gazebo + robot spawn (t=0s) ──────────────────────────────────────
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo, 'launch', 'gazebo.launch.py')),
        launch_arguments={'use_sim_time': use_sim_time}.items())

    # ── 2. Nav2 (t=8s — after robot spawned) ────────────────────────────────
    nav2 = TimerAction(
        period=8.0,
        actions=[IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_bringup, 'launch', 'nav2.launch.py')),
            launch_arguments={'use_sim_time': use_sim_time}.items())])

    # ── 3. RTAB-Map (t=10s) ─────────────────────────────────────────────────
    rtabmap = TimerAction(
        period=10.0,
        actions=[IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_bringup, 'launch', 'rtabmap.launch.py')),
            launch_arguments={'use_sim_time': use_sim_time}.items())])

    # ── 4. BT Executor (t=15s — after Nav2 is fully up) ─────────────────────
    bt_executor = TimerAction(
        period=15.0,
        actions=[Node(
            package='inspection_robot_bt',
            executable='bt_executor',
            name='bt_executor',
            output='screen',
            parameters=[{
                'use_sim_time': use_sim_time,
                'bt_file':      bt_file,
            }],
        )])

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='true'),
        gazebo,
        nav2,
        rtabmap,
        bt_executor,
    ])
