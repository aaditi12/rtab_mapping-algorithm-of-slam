#pragma once

#include <chrono>
#include <cmath>
#include <functional>
#include <memory>
#include <random>
#include <string>

#include "behaviortree_cpp/action_node.h"
#include "behaviortree_cpp/behavior_tree.h"
#include "behaviortree_cpp/bt_factory.h"
#include "behaviortree_cpp/condition_node.h"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "nav2_msgs/action/navigate_to_pose.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "std_msgs/msg/bool.hpp"
#include "std_msgs/msg/float32.hpp"
#include "std_msgs/msg/int32.hpp"
#include "std_msgs/msg/string.hpp"

namespace inspection_bt {

using NavigateToPose = nav2_msgs::action::NavigateToPose;
using NavGoalHandle  = rclcpp_action::ClientGoalHandle<NavigateToPose>;

// ─────────────────────────────────────────────────────────────────────────────
// Shared ROS node (injected via BT blackboard)
// ─────────────────────────────────────────────────────────────────────────────
struct SharedNode {
  rclcpp::Node::SharedPtr node;
};

// ─────────────────────────────────────────────────────────────────────────────
// CheckEmergency   [Condition]
//   Returns SUCCESS when emergency_flag is true (triggers inverter → halt BT).
// ─────────────────────────────────────────────────────────────────────────────
class CheckEmergency : public BT::ConditionNode {
 public:
  CheckEmergency(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus tick() override;
  static BT::PortsList providedPorts() {
    return {BT::OutputPort<bool>("emergency_flag")};
  }

 private:
  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr sub_;
  bool emergency_{false};
};

// ─────────────────────────────────────────────────────────────────────────────
// CheckObstacle    [Condition]
//   Returns SUCCESS when an obstacle is closer than min_range_threshold.
// ─────────────────────────────────────────────────────────────────────────────
class CheckObstacle : public BT::ConditionNode {
 public:
  CheckObstacle(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus tick() override;
  static BT::PortsList providedPorts() {
    return {BT::OutputPort<bool>("obstacle_detected"),
            BT::InputPort<double>("min_range_threshold")};
  }

 private:
  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_sub_;
  double min_range_{99.0};
};

// ─────────────────────────────────────────────────────────────────────────────
// CheckBatteryLow  [Condition]
//   Returns SUCCESS when battery_level < low_threshold.
// ─────────────────────────────────────────────────────────────────────────────
class CheckBatteryLow : public BT::ConditionNode {
 public:
  CheckBatteryLow(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus tick() override;
  static BT::PortsList providedPorts() {
    return {BT::OutputPort<double>("battery_level"),
            BT::InputPort<double>("low_threshold")};
  }

 private:
  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr bat_sub_;
  double battery_{100.0};
};

// ─────────────────────────────────────────────────────────────────────────────
// CheckMappingComplete  [Condition]
//   Returns SUCCESS when loop_closures >= required_closures.
// ─────────────────────────────────────────────────────────────────────────────
class CheckMappingComplete : public BT::ConditionNode {
 public:
  CheckMappingComplete(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus tick() override;
  static BT::PortsList providedPorts() {
    return {BT::OutputPort<int>("loop_closures"),
            BT::InputPort<int>("required_closures")};
  }

 private:
  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<std_msgs::msg::Int32>::SharedPtr lc_sub_;
  int loop_closures_{0};
};

// ─────────────────────────────────────────────────────────────────────────────
// BuildMapAction   [SyncActionNode]
//   Sets a blackboard flag; RTAB-Map runs as a separate node.
// ─────────────────────────────────────────────────────────────────────────────
class BuildMapAction : public BT::SyncActionNode {
 public:
  BuildMapAction(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus tick() override;
  static BT::PortsList providedPorts() {
    return {BT::OutputPort<bool>("mapping_active")};
  }

 private:
  rclcpp::Node::SharedPtr node_;
  bool announced_{false};
};

// ─────────────────────────────────────────────────────────────────────────────
// ExploreAction    [StatefulActionNode]
//   Sends a random Nav2 goal within explore_radius.
// ─────────────────────────────────────────────────────────────────────────────
class ExploreAction : public BT::StatefulActionNode {
 public:
  ExploreAction(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus onStart() override;
  BT::NodeStatus onRunning() override;
  void           onHalted() override;
  static BT::PortsList providedPorts() {
    return {BT::InputPort<double>("explore_radius"),
            BT::InputPort<double>("nav_timeout")};
  }

 private:
  void sendGoal(double x, double y);
  rclcpp::Node::SharedPtr node_;
  rclcpp_action::Client<NavigateToPose>::SharedPtr nav_client_;
  std::shared_future<NavGoalHandle::SharedPtr> goal_future_;
  NavGoalHandle::SharedPtr goal_handle_;
  rclcpp::Time goal_sent_time_;
  std::mt19937 rng_;
  bool goal_sent_{false};
};

// ─────────────────────────────────────────────────────────────────────────────
// AvoidObstacleAction  [StatefulActionNode]
//   Stops, backs up, turns, then returns SUCCESS.
// ─────────────────────────────────────────────────────────────────────────────
class AvoidObstacleAction : public BT::StatefulActionNode {
 public:
  AvoidObstacleAction(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus onStart() override;
  BT::NodeStatus onRunning() override;
  void           onHalted() override;
  static BT::PortsList providedPorts() { return {}; }

 private:
  enum class Phase { STOP, BACKUP, TURN, DONE };
  rclcpp::Node::SharedPtr node_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
  Phase phase_{Phase::STOP};
  rclcpp::Time phase_start_;
};

// ─────────────────────────────────────────────────────────────────────────────
// DockAction   [StatefulActionNode]
//   Navigates robot to dock pose (charging station).
// ─────────────────────────────────────────────────────────────────────────────
class DockAction : public BT::StatefulActionNode {
 public:
  DockAction(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus onStart() override;
  BT::NodeStatus onRunning() override;
  void           onHalted() override;
  static BT::PortsList providedPorts() {
    return {BT::InputPort<double>("dock_pose_x"),
            BT::InputPort<double>("dock_pose_y")};
  }

 private:
  rclcpp::Node::SharedPtr node_;
  rclcpp_action::Client<NavigateToPose>::SharedPtr nav_client_;
  std::shared_future<NavGoalHandle::SharedPtr> goal_future_;
  NavGoalHandle::SharedPtr goal_handle_;
  bool goal_sent_{false};
};

// ─────────────────────────────────────────────────────────────────────────────
// RechargeAction   [StatefulActionNode]
//   Waits until simulated battery reaches target_level.
// ─────────────────────────────────────────────────────────────────────────────
class RechargeAction : public BT::StatefulActionNode {
 public:
  RechargeAction(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus onStart() override;
  BT::NodeStatus onRunning() override;
  void           onHalted() override;
  static BT::PortsList providedPorts() {
    return {BT::InputPort<double>("target_level"),
            BT::OutputPort<double>("battery_level")};
  }

 private:
  rclcpp::Node::SharedPtr node_;
  rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr bat_pub_;
  double current_level_{20.0};
  double target_{90.0};
};

// ─────────────────────────────────────────────────────────────────────────────
// SaveMapAction    [SyncActionNode]
//   Calls map_saver_cli as a subprocess.
// ─────────────────────────────────────────────────────────────────────────────
class SaveMapAction : public BT::SyncActionNode {
 public:
  SaveMapAction(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus tick() override;
  static BT::PortsList providedPorts() {
    return {BT::InputPort<std::string>("map_path")};
  }

 private:
  rclcpp::Node::SharedPtr node_;
};

// ─────────────────────────────────────────────────────────────────────────────
// VoiceNotify  [SyncActionNode]
//   Publishes a string to /voice_text (espeak-ng node reads it).
// ─────────────────────────────────────────────────────────────────────────────
class VoiceNotify : public BT::SyncActionNode {
 public:
  VoiceNotify(const std::string& name, const BT::NodeConfig& cfg);
  BT::NodeStatus tick() override;
  static BT::PortsList providedPorts() {
    return {BT::InputPort<std::string>("message")};
  }

 private:
  rclcpp::Node::SharedPtr node_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr voice_pub_;
};

// ─────────────────────────────────────────────────────────────────────────────
// Registration helper
// ─────────────────────────────────────────────────────────────────────────────
void registerNodes(BT::BehaviorTreeFactory& factory,
                   rclcpp::Node::SharedPtr node);

}  // namespace inspection_bt
