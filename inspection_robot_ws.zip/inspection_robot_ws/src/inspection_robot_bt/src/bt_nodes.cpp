#include "inspection_robot_bt/bt_nodes.hpp"
#include <cstdlib>

namespace inspection_bt {

// ─── helpers ────────────────────────────────────────────────────────────────
static rclcpp::Node::SharedPtr getNode(const BT::NodeConfig& cfg) {
  std::shared_ptr<SharedNode> sh;
  cfg.blackboard->get("shared_node", sh);
  return sh->node;
}

// ═══════════════════════════════════════════════════════════════════════════
// CheckEmergency
// ═══════════════════════════════════════════════════════════════════════════
CheckEmergency::CheckEmergency(const std::string& name,
                               const BT::NodeConfig& cfg)
    : BT::ConditionNode(name, cfg), node_(getNode(cfg)) {
  sub_ = node_->create_subscription<std_msgs::msg::Bool>(
      "/emergency_stop", 10,
      [this](const std_msgs::msg::Bool::SharedPtr msg) {
        emergency_ = msg->data;
        if (emergency_) RCLCPP_WARN(node_->get_logger(), "[BT] EMERGENCY STOP!");
      });
}

BT::NodeStatus CheckEmergency::tick() {
  rclcpp::spin_some(node_);
  setOutput("emergency_flag", emergency_);
  if (emergency_) {
    RCLCPP_ERROR_THROTTLE(node_->get_logger(), *node_->get_clock(), 2000,
                          "[BT] Emergency stop active!");
    return BT::NodeStatus::SUCCESS;  // Inverter → FAILURE → halts tree
  }
  return BT::NodeStatus::FAILURE;
}

// ═══════════════════════════════════════════════════════════════════════════
// CheckObstacle
// ═══════════════════════════════════════════════════════════════════════════
CheckObstacle::CheckObstacle(const std::string& name,
                             const BT::NodeConfig& cfg)
    : BT::ConditionNode(name, cfg), node_(getNode(cfg)) {
  scan_sub_ = node_->create_subscription<sensor_msgs::msg::LaserScan>(
      "/scan", 10,
      [this](const sensor_msgs::msg::LaserScan::SharedPtr msg) {
        min_range_ = std::numeric_limits<float>::max();
        for (auto r : msg->ranges) {
          if (std::isfinite(r)) min_range_ = std::min(min_range_, (double)r);
        }
      });
}

BT::NodeStatus CheckObstacle::tick() {
  rclcpp::spin_some(node_);
  double threshold = 0.5;
  getInput("min_range_threshold", threshold);
  bool detected = min_range_ < threshold;
  setOutput("obstacle_detected", detected);
  if (detected)
    RCLCPP_WARN_THROTTLE(node_->get_logger(), *node_->get_clock(), 1000,
                         "[BT] Obstacle at %.2fm!", min_range_);
  return detected ? BT::NodeStatus::SUCCESS : BT::NodeStatus::FAILURE;
}

// ═══════════════════════════════════════════════════════════════════════════
// CheckBatteryLow
// ═══════════════════════════════════════════════════════════════════════════
CheckBatteryLow::CheckBatteryLow(const std::string& name,
                                 const BT::NodeConfig& cfg)
    : BT::ConditionNode(name, cfg), node_(getNode(cfg)) {
  bat_sub_ = node_->create_subscription<std_msgs::msg::Float32>(
      "/battery_level", 10,
      [this](const std_msgs::msg::Float32::SharedPtr msg) {
        battery_ = msg->data;
      });
}

BT::NodeStatus CheckBatteryLow::tick() {
  rclcpp::spin_some(node_);
  double threshold = 20.0;
  getInput("low_threshold", threshold);
  setOutput("battery_level", battery_);
  bool low = battery_ < threshold;
  if (low)
    RCLCPP_WARN_THROTTLE(node_->get_logger(), *node_->get_clock(), 2000,
                         "[BT] Battery low: %.1f%%", battery_);
  return low ? BT::NodeStatus::SUCCESS : BT::NodeStatus::FAILURE;
}

// ═══════════════════════════════════════════════════════════════════════════
// CheckMappingComplete
// ═══════════════════════════════════════════════════════════════════════════
CheckMappingComplete::CheckMappingComplete(const std::string& name,
                                           const BT::NodeConfig& cfg)
    : BT::ConditionNode(name, cfg), node_(getNode(cfg)) {
  lc_sub_ = node_->create_subscription<std_msgs::msg::Int32>(
      "/rtabmap/loop_closures", 10,
      [this](const std_msgs::msg::Int32::SharedPtr msg) {
        loop_closures_ = msg->data;
      });
}

BT::NodeStatus CheckMappingComplete::tick() {
  rclcpp::spin_some(node_);
  int required = 10;
  getInput("required_closures", required);
  setOutput("loop_closures", loop_closures_);
  bool complete = loop_closures_ >= required;
  RCLCPP_INFO_THROTTLE(node_->get_logger(), *node_->get_clock(), 5000,
                       "[BT] Loop closures: %d / %d", loop_closures_, required);
  return complete ? BT::NodeStatus::SUCCESS : BT::NodeStatus::FAILURE;
}

// ═══════════════════════════════════════════════════════════════════════════
// BuildMapAction
// ═══════════════════════════════════════════════════════════════════════════
BuildMapAction::BuildMapAction(const std::string& name,
                               const BT::NodeConfig& cfg)
    : BT::SyncActionNode(name, cfg), node_(getNode(cfg)) {}

BT::NodeStatus BuildMapAction::tick() {
  if (!announced_) {
    RCLCPP_INFO(node_->get_logger(),
                "[BT] RTAB-Map mapping active — building 3D environment map.");
    announced_ = true;
  }
  setOutput("mapping_active", true);
  return BT::NodeStatus::SUCCESS;
}

// ═══════════════════════════════════════════════════════════════════════════
// ExploreAction
// ═══════════════════════════════════════════════════════════════════════════
ExploreAction::ExploreAction(const std::string& name,
                             const BT::NodeConfig& cfg)
    : BT::StatefulActionNode(name, cfg),
      node_(getNode(cfg)),
      rng_(std::random_device{}()) {
  nav_client_ = rclcpp_action::create_client<NavigateToPose>(
      node_, "navigate_to_pose");
}

void ExploreAction::sendGoal(double x, double y) {
  if (!nav_client_->wait_for_action_server(std::chrono::seconds(1))) {
    RCLCPP_WARN(node_->get_logger(), "[BT] Nav2 server not available.");
    return;
  }
  NavigateToPose::Goal goal;
  goal.pose.header.frame_id = "map";
  goal.pose.header.stamp    = node_->get_clock()->now();
  goal.pose.pose.position.x = x;
  goal.pose.pose.position.y = y;
  goal.pose.pose.orientation.w = 1.0;
  RCLCPP_INFO(node_->get_logger(),
              "[BT] Exploring → target (%.2f, %.2f)", x, y);
  goal_future_ = nav_client_->async_send_goal(goal);
  goal_sent_   = true;
  goal_sent_time_ = node_->get_clock()->now();
}

BT::NodeStatus ExploreAction::onStart() {
  goal_sent_ = false;
  goal_handle_.reset();
  double radius = 6.0;
  getInput("explore_radius", radius);
  std::uniform_real_distribution<double> dist(-radius, radius);
  sendGoal(dist(rng_), dist(rng_));
  return BT::NodeStatus::RUNNING;
}

BT::NodeStatus ExploreAction::onRunning() {
  rclcpp::spin_some(node_);
  if (!goal_sent_) return BT::NodeStatus::FAILURE;

  double timeout = 30.0;
  getInput("nav_timeout", timeout);
  auto elapsed = (node_->get_clock()->now() - goal_sent_time_).seconds();
  if (elapsed > timeout) {
    RCLCPP_WARN(node_->get_logger(), "[BT] Explore goal timed out.");
    return BT::NodeStatus::SUCCESS;  // Re-pick a new goal next tick
  }

  if (goal_future_.valid() &&
      goal_future_.wait_for(std::chrono::milliseconds(0)) ==
          std::future_status::ready) {
    goal_handle_ = goal_future_.get();
    if (!goal_handle_) return BT::NodeStatus::FAILURE;
  }

  if (goal_handle_) {
    auto status = goal_handle_->get_status();
    if (status == action_msgs::msg::GoalStatus::STATUS_SUCCEEDED)
      return BT::NodeStatus::SUCCESS;
    if (status == action_msgs::msg::GoalStatus::STATUS_ABORTED ||
        status == action_msgs::msg::GoalStatus::STATUS_CANCELED)
      return BT::NodeStatus::FAILURE;
  }
  return BT::NodeStatus::RUNNING;
}

void ExploreAction::onHalted() {
  if (goal_handle_) nav_client_->async_cancel_goal(goal_handle_);
}

// ═══════════════════════════════════════════════════════════════════════════
// AvoidObstacleAction
// ═══════════════════════════════════════════════════════════════════════════
AvoidObstacleAction::AvoidObstacleAction(const std::string& name,
                                         const BT::NodeConfig& cfg)
    : BT::StatefulActionNode(name, cfg), node_(getNode(cfg)) {
  cmd_pub_ = node_->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);
}

BT::NodeStatus AvoidObstacleAction::onStart() {
  RCLCPP_INFO(node_->get_logger(), "[BT] Obstacle avoidance: STOP");
  geometry_msgs::msg::Twist stop;
  cmd_pub_->publish(stop);
  phase_      = Phase::BACKUP;
  phase_start_ = node_->get_clock()->now();
  return BT::NodeStatus::RUNNING;
}

BT::NodeStatus AvoidObstacleAction::onRunning() {
  auto now     = node_->get_clock()->now();
  auto elapsed = (now - phase_start_).seconds();
  geometry_msgs::msg::Twist cmd;

  switch (phase_) {
    case Phase::BACKUP:
      cmd.linear.x = -0.15;
      cmd_pub_->publish(cmd);
      if (elapsed > 1.5) {
        RCLCPP_INFO(node_->get_logger(), "[BT] Obstacle avoidance: TURN");
        phase_       = Phase::TURN;
        phase_start_ = now;
      }
      break;

    case Phase::TURN:
      cmd.angular.z = 0.6;
      cmd_pub_->publish(cmd);
      if (elapsed > 2.0) {
        RCLCPP_INFO(node_->get_logger(), "[BT] Obstacle avoidance: DONE");
        geometry_msgs::msg::Twist stop2;
        cmd_pub_->publish(stop2);
        return BT::NodeStatus::SUCCESS;
      }
      break;

    default:
      return BT::NodeStatus::SUCCESS;
  }
  return BT::NodeStatus::RUNNING;
}

void AvoidObstacleAction::onHalted() {
  geometry_msgs::msg::Twist stop;
  cmd_pub_->publish(stop);
}

// ═══════════════════════════════════════════════════════════════════════════
// DockAction
// ═══════════════════════════════════════════════════════════════════════════
DockAction::DockAction(const std::string& name, const BT::NodeConfig& cfg)
    : BT::StatefulActionNode(name, cfg), node_(getNode(cfg)) {
  nav_client_ = rclcpp_action::create_client<NavigateToPose>(
      node_, "navigate_to_pose");
}

BT::NodeStatus DockAction::onStart() {
  goal_sent_ = false;
  goal_handle_.reset();
  double x = -6.0, y = -6.0;
  getInput("dock_pose_x", x);
  getInput("dock_pose_y", y);

  if (!nav_client_->wait_for_action_server(std::chrono::seconds(2))) {
    RCLCPP_WARN(node_->get_logger(), "[BT] Nav2 unavailable for docking.");
    return BT::NodeStatus::FAILURE;
  }
  NavigateToPose::Goal goal;
  goal.pose.header.frame_id = "map";
  goal.pose.header.stamp    = node_->get_clock()->now();
  goal.pose.pose.position.x = x;
  goal.pose.pose.position.y = y;
  goal.pose.pose.orientation.w = 1.0;
  RCLCPP_INFO(node_->get_logger(), "[BT] Docking → (%.1f, %.1f)", x, y);
  goal_future_ = nav_client_->async_send_goal(goal);
  goal_sent_   = true;
  return BT::NodeStatus::RUNNING;
}

BT::NodeStatus DockAction::onRunning() {
  rclcpp::spin_some(node_);
  if (!goal_sent_) return BT::NodeStatus::FAILURE;

  if (goal_future_.valid() &&
      goal_future_.wait_for(std::chrono::milliseconds(0)) ==
          std::future_status::ready) {
    goal_handle_ = goal_future_.get();
    if (!goal_handle_) return BT::NodeStatus::FAILURE;
  }

  if (goal_handle_) {
    auto status = goal_handle_->get_status();
    if (status == action_msgs::msg::GoalStatus::STATUS_SUCCEEDED) {
      RCLCPP_INFO(node_->get_logger(), "[BT] Docked successfully.");
      return BT::NodeStatus::SUCCESS;
    }
    if (status == action_msgs::msg::GoalStatus::STATUS_ABORTED ||
        status == action_msgs::msg::GoalStatus::STATUS_CANCELED)
      return BT::NodeStatus::FAILURE;
  }
  return BT::NodeStatus::RUNNING;
}

void DockAction::onHalted() {
  if (goal_handle_) nav_client_->async_cancel_goal(goal_handle_);
}

// ═══════════════════════════════════════════════════════════════════════════
// RechargeAction
// ═══════════════════════════════════════════════════════════════════════════
RechargeAction::RechargeAction(const std::string& name,
                               const BT::NodeConfig& cfg)
    : BT::StatefulActionNode(name, cfg), node_(getNode(cfg)) {
  bat_pub_ = node_->create_publisher<std_msgs::msg::Float32>("/battery_level", 10);
}

BT::NodeStatus RechargeAction::onStart() {
  getInput("target_level", target_);
  RCLCPP_INFO(node_->get_logger(), "[BT] Recharging… target %.0f%%", target_);
  return BT::NodeStatus::RUNNING;
}

BT::NodeStatus RechargeAction::onRunning() {
  // Simulate recharge at 5% per second
  current_level_ = std::min(current_level_ + 0.5, target_);
  std_msgs::msg::Float32 msg;
  msg.data = static_cast<float>(current_level_);
  bat_pub_->publish(msg);
  setOutput("battery_level", current_level_);

  RCLCPP_INFO_THROTTLE(node_->get_logger(), *node_->get_clock(), 2000,
                       "[BT] Charging: %.0f%%", current_level_);

  if (current_level_ >= target_) {
    RCLCPP_INFO(node_->get_logger(), "[BT] Recharge complete!");
    return BT::NodeStatus::SUCCESS;
  }
  return BT::NodeStatus::RUNNING;
}

void RechargeAction::onHalted() {}

// ═══════════════════════════════════════════════════════════════════════════
// SaveMapAction
// ═══════════════════════════════════════════════════════════════════════════
SaveMapAction::SaveMapAction(const std::string& name,
                             const BT::NodeConfig& cfg)
    : BT::SyncActionNode(name, cfg), node_(getNode(cfg)) {}

BT::NodeStatus SaveMapAction::tick() {
  std::string path = "/tmp/inspection_map";
  getInput("map_path", path);
  RCLCPP_INFO(node_->get_logger(), "[BT] Saving RTAB-Map database…");
  // Trigger rtabmap database backup via service call (simplified: log only)
  std::string cmd = "ros2 service call /rtabmap/backup_database "
                    "std_srvs/srv/Empty '{}' &";
  std::system(cmd.c_str());
  // Also save 2D occupancy map
  std::string map_cmd =
      "ros2 run nav2_map_server map_saver_cli -f " + path + " &";
  std::system(map_cmd.c_str());
  RCLCPP_INFO(node_->get_logger(), "[BT] Map saved to %s", path.c_str());
  return BT::NodeStatus::SUCCESS;
}

// ═══════════════════════════════════════════════════════════════════════════
// VoiceNotify
// ═══════════════════════════════════════════════════════════════════════════
VoiceNotify::VoiceNotify(const std::string& name, const BT::NodeConfig& cfg)
    : BT::SyncActionNode(name, cfg), node_(getNode(cfg)) {
  voice_pub_ =
      node_->create_publisher<std_msgs::msg::String>("/voice_text", 10);
}

BT::NodeStatus VoiceNotify::tick() {
  std::string msg_text;
  getInput("message", msg_text);
  RCLCPP_INFO(node_->get_logger(), "[BT] 🔊 %s", msg_text.c_str());
  std_msgs::msg::String msg;
  msg.data = msg_text;
  voice_pub_->publish(msg);
  return BT::NodeStatus::SUCCESS;
}

// ═══════════════════════════════════════════════════════════════════════════
// Registration
// ═══════════════════════════════════════════════════════════════════════════
void registerNodes(BT::BehaviorTreeFactory& factory,
                   rclcpp::Node::SharedPtr node) {
  auto sh         = std::make_shared<SharedNode>();
  sh->node        = node;
  auto blackboard = BT::Blackboard::create();
  blackboard->set("shared_node", sh);

  factory.registerNodeType<CheckEmergency>("CheckEmergency");
  factory.registerNodeType<CheckObstacle>("CheckObstacle");
  factory.registerNodeType<CheckBatteryLow>("CheckBatteryLow");
  factory.registerNodeType<CheckMappingComplete>("CheckMappingComplete");
  factory.registerNodeType<BuildMapAction>("BuildMapAction");
  factory.registerNodeType<ExploreAction>("ExploreAction");
  factory.registerNodeType<AvoidObstacleAction>("AvoidObstacleAction");
  factory.registerNodeType<DockAction>("DockAction");
  factory.registerNodeType<RechargeAction>("RechargeAction");
  factory.registerNodeType<SaveMapAction>("SaveMapAction");
  factory.registerNodeType<VoiceNotify>("VoiceNotify");
}

}  // namespace inspection_bt
