#include <chrono>
#include <filesystem>
#include <memory>
#include <string>

#include "behaviortree_cpp/bt_factory.h"
#include "behaviortree_cpp/loggers/bt_cout_logger.h"
#include "inspection_robot_bt/bt_nodes.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/bool.hpp"
#include "std_msgs/msg/float32.hpp"

using namespace std::chrono_literals;

// ─────────────────────────────────────────────────────────────────────────────
// BatterySimulator
//   Drains battery over time.  Published on /battery_level.
// ─────────────────────────────────────────────────────────────────────────────
class BatterySimulator : public rclcpp::Node {
 public:
  BatterySimulator() : Node("battery_simulator"), level_(100.0) {
    pub_   = create_publisher<std_msgs::msg::Float32>("/battery_level", 10);
    timer_ = create_wall_timer(1s, [this]() {
      level_ -= drain_rate_;
      if (level_ < 0.0) level_ = 0.0;
      std_msgs::msg::Float32 msg;
      msg.data = static_cast<float>(level_);
      pub_->publish(msg);
      RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 10000,
                           "[Battery] %.1f%%", level_);
    });
    // Allow external recharge commands
    recharge_sub_ = create_subscription<std_msgs::msg::Float32>(
        "/battery_level", 10,
        [this](const std_msgs::msg::Float32::SharedPtr msg) {
          if (msg->data > level_) level_ = msg->data;  // Accept recharge
        });
    RCLCPP_INFO(get_logger(), "Battery simulator started (drain: %.1f%%/s)",
                drain_rate_);
  }

 private:
  double drain_rate_{0.3};  // % per second  → ~5 min to 20%
  double level_;
  rclcpp::Publisher<std_msgs::msg::Float32>::SharedPtr pub_;
  rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr recharge_sub_;
  rclcpp::TimerBase::SharedPtr timer_;
};

// ─────────────────────────────────────────────────────────────────────────────
// LoopClosureSimulator
//   Increments loop closure counter, simulating RTAB-Map progress.
// ─────────────────────────────────────────────────────────────────────────────
class LoopClosureSimulator : public rclcpp::Node {
 public:
  LoopClosureSimulator() : Node("lc_simulator"), count_(0) {
    pub_ = create_publisher<std_msgs::msg::Int32>("/rtabmap/loop_closures", 10);
    timer_ = create_wall_timer(15s, [this]() {
      ++count_;
      std_msgs::msg::Int32 msg;
      msg.data = count_;
      pub_->publish(msg);
      RCLCPP_INFO(get_logger(), "[RTAB-Map] Loop closures: %d", count_);
    });
  }

 private:
  int count_;
  rclcpp::Publisher<std_msgs::msg::Int32>::SharedPtr pub_;
  rclcpp::TimerBase::SharedPtr timer_;
};

// ─────────────────────────────────────────────────────────────────────────────
// VoiceNode
//   Subscribes to /voice_text and calls espeak-ng (if available).
// ─────────────────────────────────────────────────────────────────────────────
class VoiceNode : public rclcpp::Node {
 public:
  VoiceNode() : Node("voice_node") {
    sub_ = create_subscription<std_msgs::msg::String>(
        "/voice_text", 10,
        [this](const std_msgs::msg::String::SharedPtr msg) {
          RCLCPP_INFO(get_logger(), "[Voice] %s", msg->data.c_str());
          // Run espeak-ng in background (non-blocking)
          std::string cmd =
              "espeak-ng \"" + msg->data + "\" --stdout | aplay -q &";
          std::system(cmd.c_str());
        });
    RCLCPP_INFO(get_logger(), "Voice node ready (espeak-ng).");
  }

 private:
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr sub_;
};

// ─────────────────────────────────────────────────────────────────────────────
// BT Executor Node
// ─────────────────────────────────────────────────────────────────────────────
class BTExecutor : public rclcpp::Node {
 public:
  BTExecutor() : Node("bt_executor") {
    // Shared node pointer for BT nodes
    auto sh  = std::make_shared<inspection_bt::SharedNode>();
    sh->node = std::make_shared<rclcpp::Node>("bt_nodes_ros");

    // Build factory & register nodes
    inspection_bt::registerNodes(factory_, sh->node);

    // Inject shared_node into every BT node via blackboard
    blackboard_ = BT::Blackboard::create();
    blackboard_->set("shared_node", sh);

    // Load BT XML
    std::string bt_file =
        declare_parameter<std::string>("bt_file", "inspection_bt.xml");

    // Try to resolve from package share
    std::vector<std::string> search_paths = {
        bt_file,
        std::string(std::getenv("HOME") ? std::getenv("HOME") : "") +
            "/inspection_robot_ws/install/inspection_robot_bt/share/"
            "inspection_robot_bt/bt_trees/" +
            bt_file,
    };

    std::string resolved;
    for (const auto& p : search_paths) {
      if (std::filesystem::exists(p)) {
        resolved = p;
        break;
      }
    }
    if (resolved.empty()) {
      RCLCPP_ERROR(get_logger(), "BT file not found: %s", bt_file.c_str());
      rclcpp::shutdown();
      return;
    }

    RCLCPP_INFO(get_logger(), "Loading BT: %s", resolved.c_str());
    tree_ = factory_.createTreeFromFile(resolved, blackboard_);
    logger_ = std::make_unique<BT::StdCoutLogger>(tree_);

    // Emergency stop subscriber
    emergency_sub_ = sh->node->create_subscription<std_msgs::msg::Bool>(
        "/emergency_stop", 10,
        [this, sh](const std_msgs::msg::Bool::SharedPtr msg) {
          if (msg->data) {
            RCLCPP_ERROR(get_logger(), "🛑 EMERGENCY STOP received!");
            // Halt tree immediately
            tree_.haltTree();
            // Stop robot
            auto pub = sh->node->create_publisher<geometry_msgs::msg::Twist>(
                "/cmd_vel", 1);
            geometry_msgs::msg::Twist stop;
            pub->publish(stop);
          }
        });

    // Tick timer: 100ms tick rate
    tick_timer_ = create_wall_timer(100ms, [this, sh]() {
      rclcpp::spin_some(sh->node);
      auto status = tree_.tickOnce();
      if (status == BT::NodeStatus::SUCCESS) {
        RCLCPP_INFO(get_logger(), "✅ BT completed with SUCCESS");
        rclcpp::shutdown();
      } else if (status == BT::NodeStatus::FAILURE) {
        RCLCPP_WARN(get_logger(), "⚠️  BT returned FAILURE — re-ticking.");
      }
    });

    RCLCPP_INFO(get_logger(),
                "════════════════════════════════════════════");
    RCLCPP_INFO(get_logger(),
                "  Inspection Robot BT Executor started");
    RCLCPP_INFO(get_logger(),
                "  Publish to /emergency_stop (Bool) to halt.");
    RCLCPP_INFO(get_logger(),
                "════════════════════════════════════════════");
  }

 private:
  BT::BehaviorTreeFactory factory_;
  BT::Blackboard::Ptr blackboard_;
  BT::Tree tree_;
  std::unique_ptr<BT::StdCoutLogger> logger_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr emergency_sub_;
  rclcpp::TimerBase::SharedPtr tick_timer_;
};

// ─────────────────────────────────────────────────────────────────────────────
// main
// ─────────────────────────────────────────────────────────────────────────────
int main(int argc, char** argv) {
  rclcpp::init(argc, argv);

  auto executor = std::make_shared<rclcpp::executors::MultiThreadedExecutor>();

  auto bt_node   = std::make_shared<BTExecutor>();
  auto bat_sim   = std::make_shared<BatterySimulator>();
  auto lc_sim    = std::make_shared<LoopClosureSimulator>();
  auto voice     = std::make_shared<VoiceNode>();

  executor->add_node(bt_node);
  executor->add_node(bat_sim);
  executor->add_node(lc_sim);
  executor->add_node(voice);

  RCLCPP_INFO(rclcpp::get_logger("main"),
              "Spinning all nodes — press Ctrl+C or publish /emergency_stop "
              "to stop.");
  executor->spin();
  rclcpp::shutdown();
  return 0;
}
