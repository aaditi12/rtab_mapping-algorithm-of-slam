#!/usr/bin/env bash
# =============================================================================
#  build.sh — Build the inspection robot workspace
# =============================================================================
set -eo pipefail

WS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "📦 Workspace: $WS_DIR"

# Source ROS 2 Humble
source /opt/ros/humble/setup.bash

# Install system dependencies
echo "📥 Installing apt dependencies..."
sudo apt-get update -qq
sudo apt-get install -y --no-install-recommends \
  ros-humble-behaviortree-cpp \
  ros-humble-nav2-bringup \
  ros-humble-nav2-msgs \
  ros-humble-rtabmap-ros \
  ros-humble-gazebo-ros-pkgs \
  ros-humble-robot-state-publisher \
  ros-humble-joint-state-publisher \
  ros-humble-xacro \
  ros-humble-teleop-twist-keyboard \
  ros-humble-nav2-regulated-pure-pursuit-controller \
  espeak-ng \
  tmux

echo "🔧 Building packages..."
cd "$WS_DIR"
colcon build \
  --symlink-install \
  --cmake-args -DCMAKE_BUILD_TYPE=Release \
  --event-handlers console_cohesion+

echo ""
echo "✅ Build complete!"
echo ""
echo "Next steps:"
echo "  source install/setup.bash"
echo "  bash run.sh"
