#!/usr/bin/env bash
# =============================================================================
#  run.sh  —  build (if needed) then launch everything in tmux
#  Usage:   bash run.sh
# =============================================================================

WS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SESSION="insp_robot"

echo "================================================"
echo "  Inspection Robot — workspace: $WS"
echo "================================================"

# ── 1. Source ROS ─────────────────────────────────────────────────────────────
source /opt/ros/humble/setup.bash

# ── 2. Build ──────────────────────────────────────────────────────────────────
echo "[1/3] Building workspace..."
cd "$WS"
colcon build --symlink-install --cmake-args -DCMAKE_BUILD_TYPE=Release 2>&1 \
  | grep -E "Starting|Finished|Failed|Error|warning:|error:" || true

if [ ! -f "$WS/install/setup.bash" ]; then
  echo "ERROR: build failed — install/setup.bash not found"
  exit 1
fi
echo "[1/3] Build OK"

# ── 3. Source install ─────────────────────────────────────────────────────────
source "$WS/install/setup.bash"
echo "[2/3] Workspace sourced"

# ── 4. Verify package visible ─────────────────────────────────────────────────
if ! ros2 pkg list 2>/dev/null | grep -q "inspection_robot_bringup"; then
  echo "ERROR: inspection_robot_bringup not found after build"
  ros2 pkg list | grep inspection || true
  exit 1
fi
echo "[3/3] Package verified"

# ── 5. Launch in tmux ────────────────────────────────────────────────────────
tmux kill-session -t "$SESSION" 2>/dev/null || true
sleep 0.3

SRC="source /opt/ros/humble/setup.bash && source $WS/install/setup.bash && export LIBGL_ALWAYS_SOFTWARE=1"

tmux new-session -d -s "$SESSION" -n "launch"
tmux send-keys -t "$SESSION:launch" \
  "$SRC && ros2 launch inspection_robot_bringup inspection_robot.launch.py" Enter

sleep 1
tmux new-window -t "$SESSION" -n "bt_log"
tmux send-keys -t "$SESSION:bt_log" \
  "$SRC && sleep 16 && ros2 topic echo /voice_text" Enter

tmux new-window -t "$SESSION" -n "battery"
tmux send-keys -t "$SESSION:battery" \
  "$SRC && sleep 14 && ros2 topic echo /battery_level" Enter

tmux new-window -t "$SESSION" -n "estop"
tmux send-keys -t "$SESSION:estop" \
  "$SRC && echo 'Press ENTER to send emergency stop' && read && \
   ros2 topic pub --once /emergency_stop std_msgs/msg/Bool '{data: true}'" Enter

tmux new-window -t "$SESSION" -n "teleop"
tmux send-keys -t "$SESSION:teleop" \
  "$SRC && sleep 12 && ros2 run teleop_twist_keyboard teleop_twist_keyboard" Enter

echo ""
echo "Launched! Attaching to tmux..."
echo "  Ctrl+B 0-4  : switch windows"
echo "  Ctrl+B D    : detach"
echo ""
tmux select-window -t "$SESSION:launch"
tmux attach -t "$SESSION"
