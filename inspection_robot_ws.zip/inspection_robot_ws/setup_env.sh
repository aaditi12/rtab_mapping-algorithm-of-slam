#!/usr/bin/env bash
# Source this file to set up the inspection robot environment
# Usage: source setup_env.sh

WS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

source /opt/ros/humble/setup.bash
source "$WS/install/setup.bash"
export LIBGL_ALWAYS_SOFTWARE=1

echo "✅ Environment ready — workspace: $WS"
ros2 pkg list | grep inspection_robot
