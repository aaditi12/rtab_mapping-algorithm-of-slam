# rtab_nav_demo — RTAB-Map + RealSense D435 + 2D LiDAR

Full RGB-D SLAM using a simulated **Intel RealSense D435** + 2D LiDAR.

## Simulated D435 specs

| Property | Real D435 | Simulated |
|---|---|---|
| Body | 99×25×25 mm | ✅ matched |
| RGB FoV | 69°H × 42°V | ✅ 69° H |
| Depth FoV | 87°H × 58°V | ✅ 87° H |
| Depth range | 0.1 – 10 m | ✅ matched |
| Stereo baseline | 50 mm | ✅ matched |
| RGB rate | 30 Hz | ✅ 30 Hz |
| Depth rate | 30 Hz | ✅ 30 Hz |

## Topics (matches realsense2_camera ROS2 driver)

```
/camera/color/image_raw           RGB 1280×720
/camera/color/camera_info
/camera/depth/image_rect_raw      depth 1280×720
/camera/depth/camera_info
/camera/depth/color/points        XYZRGB point cloud
/camera/infra1/image_rect_raw     left IR
/camera/infra2/image_rect_raw     right IR
/scan                             2D LiDAR
```

## Install

```bash
sudo apt update && sudo apt install -y \
  ros-humble-rtabmap-ros \
  ros-humble-nav2-map-server \
  ros-humble-teleop-twist-keyboard \
  ros-humble-gazebo-ros-pkgs \
  ros-humble-xacro tmux
```

## Build & Run

```bash
cd ~/Downloads/rtab_ws
colcon build --packages-select rtab_nav_demo --symlink-install
source install/setup.bash
bash run_rtab_demo.sh
```

## Verify D435 publishing

```bash
ros2 topic hz /camera/color/image_raw        # ~30 Hz
ros2 topic hz /camera/depth/image_rect_raw   # ~30 Hz
ros2 topic hz /camera/depth/color/points     # ~30 Hz
ros2 topic list | grep camera                # 7 topics
```

## Save map

```bash
# 2D occupancy grid
ros2 run nav2_map_server map_saver_cli -f ~/Downloads/rtab_ws/maps/my_map
# Full RTAB-Map DB (3D + loop closures)
cp ~/.ros/rtabmap.db ~/Downloads/rtab_ws/maps/
```
