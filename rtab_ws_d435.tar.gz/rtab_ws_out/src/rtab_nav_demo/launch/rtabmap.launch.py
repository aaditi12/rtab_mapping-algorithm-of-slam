"""
rtabmap.launch.py
─────────────────
RTAB-Map with Intel RealSense D435 (RGB-D) + 2D LiDAR fusion.

D435 topic convention (mirrors realsense2_camera ROS2 driver):
  /camera/color/image_raw          — RGB 1280x720 @ 30 Hz
  /camera/color/camera_info
  /camera/depth/image_rect_raw     — depth 1280x720 @ 30 Hz
  /camera/depth/camera_info
  /camera/depth/color/points       — XYZRGB registered point cloud
  /camera/infra1/image_rect_raw    — left IR (stereo)
  /camera/infra2/image_rect_raw    — right IR (stereo)

LiDAR:
  /scan                            — sensor_msgs/LaserScan

RTAB-Map mode: RGB-D + 2D LiDAR fusion
  - Visual odometry from D435 RGB-D
  - 2D grid map from /scan (cleaner edges than depth projection)
  - 3D point cloud map from /camera/depth/color/points
  - Loop closure: visual (BoW) + geometric ICP
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    use_sim_time = LaunchConfiguration("use_sim_time", default="true")

    rtabmap_node = Node(
        package="rtabmap_slam",
        executable="rtabmap",
        name="rtabmap",
        output="screen",
        parameters=[{
            "use_sim_time": use_sim_time,

            # ── Frames ────────────────────────────────────────────────────
            "frame_id":         "base_footprint",
            "odom_frame_id":    "odom",
            "map_frame_id":     "map",

            # ── Sensor configuration ──────────────────────────────────────
            "subscribe_depth":  True,   # D435 depth
            "subscribe_rgb":    True,   # D435 color
            "subscribe_scan":   True,   # 2D LiDAR
            "subscribe_odom":   True,   # wheel odometry

            # ── Sync: D435 color and depth have same stamp in sim ─────────
            "approx_sync":      True,
            "approx_sync_max_interval": 0.02,  # 20ms tolerance
            "queue_size":       10,

            # ── D435 specific: depth scale and baseline ───────────────────
            "depth_scale":      1.0,   # Gazebo outputs metric depth

            # ── Mapping ───────────────────────────────────────────────────
            "Mem/IncrementalMemory":     "true",
            "Mem/InitWMWithAllNodes":    "false",
            "RGBD/NeighborLinkRefining": "true",
            "RGBD/ProximityBySpace":     "true",
            "RGBD/AngularUpdate":        "0.01",
            "RGBD/LinearUpdate":         "0.01",
            "RGBD/OptimizeFromGraphEnd": "false",

            # ── 2D grid from LiDAR (not depth projection) ─────────────────
            # Produces cleaner walls in structured indoor environments
            "Grid/FromDepth":   "false",
            "Grid/RayTracing":  "true",
            "Grid/CellSize":    "0.05",

            # ── 3D map from D435 point cloud ──────────────────────────────
            "cloud_voxel_size": "0.05",

            # ── Loop closure (visual BoW) ─────────────────────────────────
            "Kp/MaxFeatures":   "500",
            "Vis/MinInliers":   "15",
            "Vis/EstimationType": "1",  # 3D->3D (RGB-D mode)

            # ── D435 depth range limits ───────────────────────────────────
            "depth_min":        0.1,
            "depth_max":        10.0,

            # ── Performance budget ────────────────────────────────────────
            "Rtabmap/TimeThr":  "700",

            # ── Database path ─────────────────────────────────────────────
            "database_path":    "~/.ros/rtabmap.db",
        }],
        remappings=[
            # D435 RGB (realsense2_camera driver topic names)
            ("rgb/image",           "/camera/color/image_raw"),
            ("rgb/camera_info",     "/camera/color/camera_info"),
            # D435 depth
            ("depth/image",         "/camera/depth/image_rect_raw"),
            # D435 point cloud (registered RGB-D)
            ("scan",                "/scan"),
            ("odom",                "/odom"),
        ],
    )

    # ── Point cloud assembler: republish /camera/depth/color/points → /rtabmap/cloud_map ──
    # (optional — uncomment rtabmap_viz below for the 3D viewer)

    return LaunchDescription([
        DeclareLaunchArgument(
            "use_sim_time",
            default_value="true",
            description="Use Gazebo simulation clock",
        ),
        rtabmap_node,
    ])
