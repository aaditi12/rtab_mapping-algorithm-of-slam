import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    TimerAction,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch_ros.parameter_descriptions import ParameterValue   # ← THE FIX


def generate_launch_description():

    pkg = get_package_share_directory("rtab_nav_demo")

    declare_x   = DeclareLaunchArgument("x_pose", default_value="-1.8")
    declare_y   = DeclareLaunchArgument("y_pose", default_value="3.0")
    declare_yaw = DeclareLaunchArgument("yaw",    default_value="-1.5708")

    xacro_file = os.path.join(pkg, "urdf", "diff_robot.urdf.xacro")

    # Wrap in ParameterValue(value_type=str) — required in Humble so launch
    # doesn't try to parse the URDF XML string as YAML and crash.
    robot_desc = ParameterValue(Command(["xacro ", xacro_file]), value_type=str)

    world_file = os.path.join(pkg, "worlds", "slam_world.world")

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution(
                [FindPackageShare("gazebo_ros"), "launch", "gazebo.launch.py"]
            )
        ),
        launch_arguments={
            "world": world_file,
            "verbose": "false",
            "pause": "false",
        }.items(),
    )

    rsp = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[{
            "robot_description": robot_desc,
            "use_sim_time": True,
        }],
    )

    spawn = TimerAction(
        period=3.0,
        actions=[
            Node(
                package="gazebo_ros",
                executable="spawn_entity.py",
                name="spawn_robot",
                output="screen",
                arguments=[
                    "-entity", "diff_robot",
                    "-topic",  "/robot_description",
                    "-x", LaunchConfiguration("x_pose"),
                    "-y", LaunchConfiguration("y_pose"),
                    "-z", "0.15",
                    "-Y", LaunchConfiguration("yaw"),
                ],
            )
        ],
    )

    return LaunchDescription([
        declare_x,
        declare_y,
        declare_yaw,
        gazebo,
        rsp,
        spawn,
    ])
