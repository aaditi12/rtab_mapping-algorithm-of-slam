#!/usr/bin/env python3
"""
map_subscriber.py
─────────────────
Subscribes to /map (nav_msgs/OccupancyGrid) and:
  • Logs map metadata whenever a new map arrives
  • Prints a tiny ASCII minimap in the terminal
  • Optionally saves a PNG snapshot every N updates
"""

import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
import numpy as np
import math


ASCII_CHARS = {
    -1:  "·",   # unknown
    0:   " ",   # free
    100: "█",   # occupied
}


def to_ascii(value: int) -> str:
    if value < 0:
        return ASCII_CHARS[-1]
    if value < 50:
        return ASCII_CHARS[0]
    return ASCII_CHARS[100]


class MapSubscriber(Node):

    MINIMAP_WIDTH  = 60
    MINIMAP_HEIGHT = 20

    def __init__(self):
        super().__init__("map_subscriber")
        self._map_count = 0
        self.sub = self.create_subscription(
            OccupancyGrid, "/map", self._map_cb, 10
        )
        self.get_logger().info("MapSubscriber ready — waiting for /map …")

    # ─────────────────────────────────────────────────────────────
    def _map_cb(self, msg: OccupancyGrid):
        self._map_count += 1
        info = msg.info

        # ── Metadata ──
        width_m  = info.width  * info.resolution
        height_m = info.height * info.resolution
        data     = np.array(msg.data, dtype=np.int8)
        free     = int(np.sum(data == 0))
        occ      = int(np.sum(data == 100))
        unk      = int(np.sum(data == -1))

        self.get_logger().info(
            f"\n{'═'*55}\n"
            f"  MAP UPDATE #{self._map_count}\n"
            f"  Size      : {info.width} × {info.height} cells\n"
            f"  Real size : {width_m:.2f} m × {height_m:.2f} m\n"
            f"  Resolution: {info.resolution:.3f} m/cell\n"
            f"  Origin    : ({info.origin.position.x:.2f}, "
            f"{info.origin.position.y:.2f})\n"
            f"  Free cells: {free}  Occupied: {occ}  Unknown: {unk}\n"
            f"  Explored  : {100*(free+occ)/max(1, len(data)):.1f} %\n"
            f"{'═'*55}"
        )

        self._print_ascii_minimap(data, info.width, info.height)

    # ─────────────────────────────────────────────────────────────
    def _print_ascii_minimap(self, data, w, h):
        scale_x = max(1, w  // self.MINIMAP_WIDTH)
        scale_y = max(1, h // self.MINIMAP_HEIGHT)
        lines   = []
        border  = "+" + "-" * self.MINIMAP_WIDTH + "+"
        lines.append(border)
        for row in range(0, h, scale_y):
            if len(lines) - 1 >= self.MINIMAP_HEIGHT:
                break
            line = "|"
            for col in range(0, w, scale_x):
                if len(line) - 1 >= self.MINIMAP_WIDTH:
                    break
                idx   = row * w + col
                val   = int(data[idx]) if idx < len(data) else -1
                line += to_ascii(val)
            line += "|"
            lines.append(line)
        lines.append(border)
        self.get_logger().info("\n" + "\n".join(lines))


def main(args=None):
    rclpy.init(args=args)
    node = MapSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
