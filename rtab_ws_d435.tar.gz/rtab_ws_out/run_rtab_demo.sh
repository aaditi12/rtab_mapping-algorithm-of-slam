#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  run_rtab_demo.sh
#  ────────────────
#  Gazebo + RTAB-Map RGB-D SLAM + RViz + Teleop
#
#  Prerequisites (install once):
#    sudo apt install tmux ros-humble-rtabmap-ros \
#         ros-humble-teleop-twist-keyboard         \
#         ros-humble-gazebo-ros-pkgs               \
#         ros-humble-xacro
#
#  Usage:
#    cd ~/Downloads/rtab_ws
#    colcon build --packages-select rtab_nav_demo --symlink-install
#    source install/setup.bash
#    bash run_rtab_demo.sh
# ═══════════════════════════════════════════════════════════════════
set -e

SESSION="rtab_demo"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_DIR="${ROS2_WS:-$SCRIPT_DIR}"
SETUP="source $WS_DIR/install/setup.bash"
DELAY_GAZEBO=7      # RTAB-Map needs camera topics to be ready
DELAY_RTAB=5

GREEN="\033[1;32m"; YELLOW="\033[1;33m"; CYAN="\033[1;36m"; NC="\033[0m"
info() { echo -e "${CYAN}[rtab_demo]${NC} $*"; }
ok()   { echo -e "${GREEN}[  OK  ]${NC} $*"; }

command -v tmux >/dev/null || { echo "❌  tmux not found"; exit 1; }
command -v ros2  >/dev/null || { echo "❌  ROS2 not sourced"; exit 1; }
[ -f "$WS_DIR/install/setup.bash" ] || {
  echo "❌  Not built. Run: colcon build --packages-select rtab_nav_demo --symlink-install"
  exit 1
}

killall -9 gzserver gzclient 2>/dev/null && info "Killed stale Gazebo" || true
tmux kill-session -t "$SESSION" 2>/dev/null || true
sleep 1

info "Starting RTAB-Map demo …"

# 0: Gazebo + robot
tmux new-session -d -s "$SESSION" -x 220 -y 50
tmux rename-window -t "$SESSION:0" "Gazebo"
tmux send-keys -t "$SESSION:0" \
  "export LIBGL_ALWAYS_SOFTWARE=1 && $SETUP && \
   ros2 launch rtab_nav_demo gazebo_spawn.launch.py" Enter

# 1: RTAB-Map
tmux new-window -t "$SESSION" -n "RTAB-Map"
tmux send-keys -t "$SESSION:1" \
  "sleep $DELAY_GAZEBO && $SETUP && \
   echo '🗺️  Starting RTAB-Map …' && \
   ros2 launch rtab_nav_demo rtabmap.launch.py" Enter

# 2: RViz
tmux new-window -t "$SESSION" -n "RViz"
tmux send-keys -t "$SESSION:2" \
  "sleep $((DELAY_GAZEBO + DELAY_RTAB)) && export LIBGL_ALWAYS_SOFTWARE=1 && \
   $SETUP && ros2 launch rtab_nav_demo rviz.launch.py" Enter

# 3: Map subscriber
tmux new-window -t "$SESSION" -n "MapSub"
tmux send-keys -t "$SESSION:3" \
  "sleep $((DELAY_GAZEBO + DELAY_RTAB)) && $SETUP && \
   ros2 run rtab_nav_demo map_subscriber.py" Enter

# 4: Teleop
tmux new-window -t "$SESSION" -n "Teleop"
tmux send-keys -t "$SESSION:4" \
  "sleep $((DELAY_GAZEBO + DELAY_RTAB + 1)) && $SETUP && \
   echo '🕹️  Drive to build RGB-D map!' && \
   echo '    i=fwd  ,=back  j=left  l=right  k=stop  q/z=speed' && \
   ros2 run teleop_twist_keyboard teleop_twist_keyboard \
     --ros-args --remap cmd_vel:=/cmd_vel" Enter

tmux select-window -t "$SESSION:4"

ok "All 5 components launching"
echo ""
echo -e "${YELLOW}Attach:${NC}  tmux attach -t $SESSION"
echo ""
echo -e "${YELLOW}Windows (Ctrl+B + number):${NC}"
echo "  0→Gazebo  1→RTAB-Map  2→RViz  3→MapSub  4→Teleop ← drive here"
echo ""
echo -e "${YELLOW}Save 2D map:${NC}"
echo "  ros2 run nav2_map_server map_saver_cli -f ~/Downloads/rtab_ws/maps/my_map"
echo ""
echo -e "${YELLOW}Export 3D map (.ot octomap):${NC}"
echo "  ros2 service call /rtabmap/export_3d_map std_srvs/srv/Empty"
echo ""
echo -e "${YELLOW}Kill:${NC}"
echo "  tmux kill-session -t $SESSION && killall -9 gzserver gzclient"
echo ""

tmux attach -t "$SESSION"
